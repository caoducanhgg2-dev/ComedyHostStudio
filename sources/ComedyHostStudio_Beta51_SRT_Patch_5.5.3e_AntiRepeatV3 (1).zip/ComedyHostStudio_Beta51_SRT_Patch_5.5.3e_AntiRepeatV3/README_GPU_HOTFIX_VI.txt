5.5.3b GPU RECOVERY

Cài đặt:
1. Bấm Dừng và đóng hoàn toàn Comedy Host Studio.
2. Giải nén ZIP này.
3. Chạy INSTALL_PATCH.bat.
4. Mở app và chạy lại video.

Dấu hiệu đúng:
- Trước khi phân tích video, log có: GPU ACTIVE: Visual Brain dùng ... GB VRAM.
- Khi cảnh đầu chạy, log qwen3-vl phải hiện GPU ACTIVE, không được hiện CPU / chưa ghi nhận VRAM.
- RTX 2070 8GB thường phải dùng nhiều GB Dedicated GPU Memory khi Visual Brain hoạt động.

Nếu preflight không đạt, app sẽ dừng ngay để tránh mất thời gian chạy CPU.
File cần gửi nếu vẫn lỗi: %%LOCALAPPDATA%%\ComedyHostStudioData\GPU_PREFLIGHT_5.5.3b.json và ollama.log.


5.5.3b: Nếu preflight đầu tiên bị HTTP 500, app tự thử lại với Ollama auto. Không còn ép 999 GPU layers và không tắt memory-fit.
