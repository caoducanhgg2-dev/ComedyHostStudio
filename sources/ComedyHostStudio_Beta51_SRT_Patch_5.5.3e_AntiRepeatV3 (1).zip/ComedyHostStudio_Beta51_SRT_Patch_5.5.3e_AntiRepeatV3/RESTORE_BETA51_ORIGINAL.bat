@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "APPDIR=%LOCALAPPDATA%\Programs\ComedyHostStudio"
set "BACKUP=%APPDIR%\Backup_Beta51_PreSRTPatch"

for /f "tokens=1" %%P in ('tasklist /FI "IMAGENAME eq ComedyHostStudio.exe" /NH 2^>nul') do (
  if /I "%%P"=="ComedyHostStudio.exe" (
    echo Hay dong Comedy Host Studio truoc khi khoi phuc.
    pause
    exit /b 2
  )
)
if not exist "%BACKUP%\engine.py" (
  echo Khong tim thay ban sao engine.py goc.
  pause
  exit /b 1
)
copy /y "%BACKUP%\engine.py" "%APPDIR%\engine.py" >nul
if exist "%BACKUP%\voice_catalog.json" copy /y "%BACKUP%\voice_catalog.json" "%APPDIR%\voice_catalog.json" >nul
del /q "%APPDIR%\trend_us.json" 2>nul
del /q "%APPDIR%\trend_jp.json" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.2.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.2.1.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.2.2.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.3.0.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.3.1.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.4.0.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.4.1.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.4.2.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.4.3.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.0.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.1.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.2.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.3.txt" 2>nul

echo Da khoi phuc Beta 5.1 goc.
start "" "%APPDIR%\ComedyHostStudio.exe"
exit /b 0
