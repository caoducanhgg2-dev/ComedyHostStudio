@echo off
setlocal
set "APPDIR=%LOCALAPPDATA%\Programs\ComedyHostStudio"
echo === CHECK SMART REVIEWER GOLDSTYLE PATCH 5.5.3e ANTI-REPEAT V3 ===
if exist "%APPDIR%\SRT_PATCH_5.5.3e.txt" (
  type "%APPDIR%\SRT_PATCH_5.5.3e.txt"
) else (
  echo Chua thay marker patch 5.5.3e.
)
findstr /C:"1.1.0-beta5.5.3e-anti-repeat-v3" "%APPDIR%\engine.py" >nul 2>nul && echo ENGINE: OK || echo ENGINE: CHUA PATCH
findstr /C:"num_gpu" "%APPDIR%\engine.py" >nul 2>nul && echo FORCED GPU OFFLOAD: OK || echo FORCED GPU OFFLOAD: THIEU
findstr /C:"GPU_PREFLIGHT_5.5.3b.json" "%APPDIR%\engine.py" >nul 2>nul && echo GPU PREFLIGHT: OK || echo GPU PREFLIGHT: THIEU
findstr /C:"GLOBAL ANTI-REPEAT GATE" "%APPDIR%\engine.py" >nul 2>nul && echo GLOBAL ANTI-REPEAT: OK || echo GLOBAL ANTI-REPEAT: THIEU
findstr /C:"strict_repeat_issue" "%APPDIR%\engine.py" >nul 2>nul && echo STRICT REPEAT LEDGER: OK || echo STRICT REPEAT LEDGER: THIEU
findstr /C:"FINAL ANTI-REPEAT V3" "%APPDIR%\engine.py" >nul 2>nul && echo FINAL REPEAT GATE: OK || echo FINAL REPEAT GATE: THIEU
findstr /C:"STORYFLOW DRAFT PASS" "%APPDIR%\engine.py" >nul 2>nul && echo STORYFLOW DRAFT: OK || echo STORYFLOW DRAFT: THIEU
findstr /C:"GOLDSTYLE HOOK PASS" "%APPDIR%\engine.py" >nul 2>nul && echo GOLDSTYLE HOOK: OK || echo GOLDSTYLE HOOK: THIEU
findstr /C:"GOLDSTYLE PERSONALITY PASS" "%APPDIR%\engine.py" >nul 2>nul && echo PERSONALITY PASS: OK || echo PERSONALITY PASS: THIEU
findstr /C:"STORYFLOW CAPTION PASS" "%APPDIR%\engine.py" >nul 2>nul && echo STORYFLOW CAPTIONIZE: OK || echo STORYFLOW CAPTIONIZE: THIEU
findstr /C:"semantic_template_family" "%APPDIR%\engine.py" >nul 2>nul && echo SEMANTIC ANTI-FILLER: OK || echo SEMANTIC ANTI-FILLER: THIEU
findstr /C:"Narrative_Draft.json" "%APPDIR%\engine.py" >nul 2>nul && echo NARRATIVE DRAFT: OK || echo NARRATIVE DRAFT: THIEU
findstr /C:"Vietnamese_QA.json" "%APPDIR%\engine.py" >nul 2>nul && echo VIETNAMESE QA: OK || echo VIETNAMESE QA: THIEU
findstr /C:"WRITER_MODEL_8B" "%APPDIR%\engine.py" >nul 2>nul && echo DUAL BRAIN: OK || echo DUAL BRAIN: THIEU
if exist "%APPDIR%\trend_us.json" (echo TREND US: OK) else (echo TREND US: THIEU)
if exist "%APPDIR%\trend_jp.json" (echo TREND JP: OK) else (echo TREND JP: THIEU)
findstr /C:"srt_us" "%APPDIR%\voice_catalog.json" >nul 2>nul && echo SRT US: OK || echo SRT US: THIEU
findstr /C:"srt_jp" "%APPDIR%\voice_catalog.json" >nul 2>nul && echo SRT JP: OK || echo SRT JP: THIEU
pause
