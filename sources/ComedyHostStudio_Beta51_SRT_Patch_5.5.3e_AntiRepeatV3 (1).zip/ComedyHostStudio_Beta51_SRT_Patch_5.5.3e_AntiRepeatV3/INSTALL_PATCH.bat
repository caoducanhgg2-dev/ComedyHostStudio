@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "APPDIR=%LOCALAPPDATA%\Programs\ComedyHostStudio"
set "BACKUP=%APPDIR%\Backup_Beta51_PreSRTPatch"
set "HERE=%~dp0"

echo.
echo === Comedy Host Studio Beta 5.1 - SMART REVIEWER GOLDSTYLE 5.5.3e ANTI-REPEAT V3 ===
echo.

if not exist "%APPDIR%\engine.py" (
  echo KHONG TIM THAY Beta 5.1 tai:
  echo %APPDIR%
  echo Hay cai Beta 5.1 truoc roi chay lai patch.
  pause
  exit /b 1
)

for /f "tokens=1" %%P in ('tasklist /FI "IMAGENAME eq ComedyHostStudio.exe" /NH 2^>nul') do (
  if /I "%%P"=="ComedyHostStudio.exe" (
    echo Comedy Host Studio dang mo. Hay dong app roi chay lai patch.
    pause
    exit /b 2
  )
)

if not exist "%BACKUP%" mkdir "%BACKUP%"
if not exist "%BACKUP%\engine.py" copy /y "%APPDIR%\engine.py" "%BACKUP%\engine.py" >nul
if not exist "%BACKUP%\voice_catalog.json" copy /y "%APPDIR%\voice_catalog.json" "%BACKUP%\voice_catalog.json" >nul

copy /y "%HERE%engine.py" "%APPDIR%\engine.py" >nul || goto :fail
copy /y "%HERE%voice_catalog.json" "%APPDIR%\voice_catalog.json" >nul || goto :fail
copy /y "%HERE%trend_us.json" "%APPDIR%\trend_us.json" >nul || goto :fail
copy /y "%HERE%trend_jp.json" "%APPDIR%\trend_jp.json" >nul || goto :fail

del /q "%APPDIR%\SRT_PATCH_5.4.3.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.0.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.1.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.2.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.3.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.3a.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.3b.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.3c.txt" 2>nul
del /q "%APPDIR%\SRT_PATCH_5.5.3d.txt" 2>nul
> "%APPDIR%\SRT_PATCH_5.5.3e.txt" echo 1.1.0-beta5.5.3e-anti-repeat-v3

echo.
echo DA CAI SMART REVIEWER GOLDSTYLE 5.5.3e ANTI-REPEAT V3 THANH CONG.
echo.
echo 5.5.3 GOLDSTYLE:
echo   - Chuan CapCut US moi: muc tieu 10 tu/caption, slot ~4.08s, gap 0.10s.
echo   - Dua tren RAMPE3 mau nguoi dung da test CapCut nghe muot.
echo   - KHONG con hard-code 6-8 tu/caption cho US.
echo   - Phong cach US theo mau reviewer/comedy: hook, reaction, playful comparison, punchline nhe.
echo   - 3 caption dau co GoldStyle Hook Pass bat buoc: curiosity ^> escalation ^> open loop.
echo   - Them GoldStyle Personality Pass cho cac doan kho/repetitive, khong con vision-log.
echo   - Humor chi la observational, phai bam evidence; khong bia su kien/muc dich/ket qua.
echo   - Final Rhythm Pass nham dua US ve DUNG 10 tu khi co the, khong cat cau giua chung.
echo   - StoryFlow van viet mach 20-30s truoc roi moi captionize.
echo   - JP giu writer rieng va nhip rieng 15-20 ky tu; khong dich tu US.
echo   - Them Style_QA.json de cham hook/reviewer voice/humor coverage/rhythm.
echo   - Vietnamese_Translation.txt va Vietnamese_QA.json van giu.
echo   - RTX 2070: dung Safe GPU Auto: num_gpu=-1 + main_gpu=0; Ollama tu chon so layer vua VRAM.
echo   - Vision context 4K tren GPU 8GB de du VRAM cho model layers.
echo   - CUDA GPU 0 duoc uu tien; khong tat bo nho fit cua Ollama.
echo   - GPU preflight thu Safe GPU Auto; neu runner tu choi thi thu lai Ollama auto mot lan.
echo   - Neu ca 2 lan deu loi, app bao loi gon va ghi GPU_PREFLIGHT_5.5.3b.json thay vi traceback HTTP 500.
echo   - GoldStyle/Hook/Comedy/10 tu-caption cua 5.5.3 duoc giu nguyen.
echo   - 5.5.3d: sua dung nguyen nhan loop theo narrative window, khong chi quet cuoi pipeline.
echo   - Captionizer + Fallback bi validator chan NGAY neu lap cau, near-duplicate, opening hoac catchphrase da dung.
echo   - Repeat Ledger nho toan bo video: used openings + phrase families + den 80 line gan nhat.
echo   - Catchphrase nhu DIY wizard / secret weapon / real magic / proper payoff khong duoc xoay vong lai.
echo   - Global Anti-Repeat chay 3 pass, sau do co Final Fresh-Wording Gate tu evidence cua tung timestamp.
echo   - Neu van con loop, app KHONG xuat SRT lap; ghi Repeat_QA_FAIL.json de chan ket qua xau.
echo   - GIU NGUYEN GoldStyle, ban dich, hook, humor, 10 tu/caption, 0.10s gap va GPU Recovery 5.5.3b.
echo   - 5.5.3e: tach HARD LOOP khoi factual similarity. Exact/catchphrase/reviewer loop van bi chan; mo ta cung hanh dong 0.82-0.89 chi canh bao.
echo   - Final Gate V3 sua TUNG caption doc lap; 1 caption sai word-count khong con lam hong ca batch.
echo   - Them deterministic exact-word normalizer nhe cho candidate 9/11 tu, khong bia su kien.
echo   - 3 caption 15/26/35 trong Repeat_QA_FAIL 5.5.3d se khong con bi coi la loi hard neu chi la mo ta factual gan nhau.
echo.
echo LAN DAU 5.5 co the tai Writer AI neu may chua co model. Sau do AI chay local, khong API key.
echo.
echo Ten nut van la "Tao audio" do giao dien EXE Beta 5.1 duoc giu nguyen.
echo Khi chon SRT US/JP, app KHONG tao Voice/MP3/BGM/SFX.
echo.
start "" "%APPDIR%\ComedyHostStudio.exe"
exit /b 0

:fail
echo.
echo LOI: khong sao chep duoc file patch.
echo Thu chuot phai INSTALL_PATCH.bat ^> Run as administrator.
pause
exit /b 3
