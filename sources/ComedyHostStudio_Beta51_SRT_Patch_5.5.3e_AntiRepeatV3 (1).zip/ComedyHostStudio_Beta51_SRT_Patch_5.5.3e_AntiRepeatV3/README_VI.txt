COMEDY HOST STUDIO BETA 5.1 - SMART REVIEWER 5.5.3e GOLDSTYLE + ANTI-REPEAT V3

MỤC TIÊU
Bản 5.5.3 được hiệu chỉnh từ 2 chuẩn người dùng đã xác nhận:
1) RAMPE3(1).srt = chuẩn NHỊP CAPCUT: 66 caption, đúng 10 từ/caption, active ~4.08s, gap 0.10s.
2) SỬA THEO CÁCH NÀY.txt = chuẩn PHONG CÁCH: American reviewer/comedy host có hook, reaction, playful comparison, punchline nhẹ.

NGUYÊN TẮC QUAN TRỌNG
- Hai chuẩn KHÔNG bị trộn lẫn: file phong cách chỉ dạy CÁCH VIẾT; RAMPE3 chỉ dạy TIMING + WORD BUDGET.
- US target chính = 10 từ/caption. Writer được phép tạm 9-11 để giữ câu tự nhiên, nhưng Final Rhythm sẽ cố đưa về đúng 10.
- Slot US quay lại ~4.08s, gap 0.10s. Không dùng 3.35s / 6-8 từ của 5.5.2 nữa.
- Không cắt cụt câu để đủ từ.
- Factual grounding vẫn ưu tiên cao: được hài ở CÁCH NÓI, không bịa SỰ KIỆN.

KIẾN TRÚC
VIDEO
-> Visual Brain / Event Map
-> Story Brain / Creative Plan
-> StoryFlow Draft 25-30s
-> Captionize 10-word Gold Rhythm
-> GoldStyle Hook Pass (3 caption đầu bắt buộc)
-> GoldStyle Personality Pass (các đoạn khô/lặp)
-> Global Creative Editor
-> Fact Guard + Semantic Anti-Filler
-> Exact-10 Rhythm Repair
-> Global Anti-Repeat Gate (quet toan bo script, sua caption lap)
-> SRT
-> Vietnamese Natural Review + QA

PHONG CÁCH US
- American TikTok reviewer/comedy host đang xem cùng khán giả.
- Có cá tính: okay / wait / look / reaction / playful metaphor / light punchline.
- Hài nhẹ theo cảnh thật: effort, craftsmanship, difficulty, before-after, comparison, expectation.
- Không biến mọi câu thành joke; khoảng 15-30% câu có humor/personality rõ là đủ.
- Không dùng kiểu vision log: “He adjusts X”, “The setup takes shape” lặp liên tục.
- Hook 3 caption đầu phải là một chuỗi:
  1. unusual reaction/question;
  2. escalate bằng chi tiết thật;
  3. open loop dựa trên payoff đã xác minh, không spoil.

JAPANESE
- Giữ writer Nhật riêng.
- Không dịch từ US.
- Giữ profile 15-20 ký tự/caption và phong cách reviewer Nhật tự nhiên, ツッコミ nhẹ.

OUTPUT QA MỚI
- Style_QA.json: Hook Strength / Reviewer Voice / Humor Coverage / Hook Rewrites / Personality Rewrites.
- Reviewer_QA.json: thêm exact Gold Rhythm ratio và các chỉ số phong cách.
- Các file cũ vẫn giữ: Narrative_Draft, Content_QA, Repeat_QA, Vietnamese_Translation, Vietnamese_QA, Performance_QA, SRT_QA.

CÀI ĐẶT
1. Đóng Comedy Host Studio.
2. Giải nén ZIP.
3. Chạy INSTALL_PATCH.bat.
4. Chọn SRT US hoặc SRT JP.
5. Test lại cùng video để so trực tiếp 5.5.2 -> 5.5.3.

LƯU Ý
- Giao diện EXE Beta 5.1 giữ nguyên nên nút vẫn có tên “Tạo audio”.
- Preset SRT US/JP không tạo MP3/BGM/SFX.
- AI chạy local, không API key.


HOTFIX 5.5.3c - CHỈ SỬA LẶP
- Không thay đổi phong cách reviewer/comedy đã duyệt.
- Không thay đổi Hook Pass.
- Không thay đổi target 10 từ/caption, slot ~4.08s, gap 0.10s.
- Không thay đổi GPU Recovery 5.5.3b.
- Captionizer và fallback được cấp lịch sử dài hơn: 28 caption trước thay vì 10.
- Sau toàn bộ Editor + Rhythm, app quét toàn bộ script để tìm exact/near duplicate ở xa nhau.
- Chỉ các caption lặp mới được rewrite theo evidence của chính timestamp đó.
- Mỗi câu thay thế phải khác opening/catchphrase và vẫn đúng 10 từ.
- Chạy tối đa 2 pass theo batch, không retry từng caption.
- Repeat_QA/Reviewer_QA/Content_QA ghi lại dedupe_rewrites để kiểm tra.


HOTFIX 5.5.3d - ANTI-REPEAT V2 (SỬA LOOP THEO WINDOW)
- Giữ nguyên phong cách và bản dịch 5.5.3c; chỉ sửa repetition.
- Test thực tế 5.5.3c cho thấy 40 caption nhưng chỉ 12 câu EN khác nhau: Writer xoay vòng một bộ câu mẫu theo narrative window 7 caption.
- 5.5.3d chặn lặp ngay ở StoryFlow Captionizer và Fallback bằng whole-video Repeat Ledger.
- Exact duplicate, near duplicate, reviewer opening và catchphrase family đều bị reject và AI phải viết lại trước khi batch được chấp nhận.
- Các phrase family nổi bật chỉ dùng một lần/video: DIY wizard, tank comparison, secret weapon, proper payoff, real magic, heavy lifting, trick of light, jackpot...
- Global Anti-Repeat tăng lên 3 pass.
- Nếu vẫn còn lặp, Final Fresh-Wording Gate viết lại từ evidence của đúng timestamp, không paraphrase câu lặp.
- Nếu Final Gate vẫn không đạt, app không xuất SRT lặp và ghi Repeat_QA_FAIL.json; cache phân tích video vẫn giữ.
- Không đổi GPU Recovery 5.5.3b, 10 từ/caption, slot ~4.08s, gap 0.10s, GoldStyle, Japanese profile hoặc Vietnamese translation.


HOTFIX 5.5.3e - ANTI-REPEAT V3 (SỬA FALSE POSITIVE + BATCH REJECT)
- Kiểm tra Repeat_QA_FAIL 5.5.3d thực tế: còn 3 caption bị chặn ở near duplicate 0.84/0.86/0.88 dù đều là mô tả factual khác nhau.
- Nguyên nhân thứ hai: Global/Final Gate validator reject cả batch nếu chỉ 1 caption lệch 10 từ (ví dụ 13 -> 9 -> 12 từ).
- 5.5.3e tách HARD LOOP và FACTUAL SIMILARITY:
  + HARD: exact duplicate, catchphrase family lặp, reviewer opening lặp, reviewer paraphrase quá gần, phrase dài bị copy.
  + SOFT: cùng hành động thật ở timestamp khác với similarity vừa phải; ghi QA nhưng KHÔNG làm job fail.
- Final Gate V3 sửa từng caption độc lập tối đa 3 lần. Một caption lỗi không làm mất các edit tốt khác.
- Candidate 9/11 từ có deterministic word-fit bảo thủ để về đúng 10 khi có thể, không tạo sự kiện mới.
- Repeat_QA.json có thêm nonfatal_factual_similarity để theo dõi.
- Giữ nguyên GoldStyle, 10 từ/caption, ~4.08s, gap 0.10s, GPU Recovery 5.5.3b, JP writer và Vietnamese Translation.
